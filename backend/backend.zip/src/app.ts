import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import productsRouter from "./routes/products.js";
import barangRouter from "./routes/barang.js";
import variantProdukRouter from "./routes/variant-produk.js";
import productionOrdersRouter from "./routes/production-orders.js";
import stylesRouter from "./routes/styles.js";
import colorsRouter from "./routes/colors.js";
import sizesRouter from "./routes/sizes.js";
import statusBarangRouter from "./routes/statusBarang.js";
import statusTransitionRouter from "./routes/statusTransition.js";
import barangGroupRouter from "./routes/barangGroup.js";
import adminRouter from "./routes/admin.js";
import authRouter from "./routes/auth.js";
import integrasiJurnalRouter from "./routes/integrasi-jurnal.js";
import karyawanRouter from "./routes/karyawan.js";
import permintaanBarangRouter from "./routes/permintaan-barang.js";
import divisiRouter from "./routes/divisi.js";
import batchesRouter from "./routes/batch.js";
import userRouter from "./routes/user.js";
import roleRouter from "./routes/role.js";
import itemRouter from "./routes/item.js";
import stokOpnameRouter from "./routes/stokOpname.js";
import gudangRouter from "./routes/gudang.js";
import mutasiGudangRouter from "./routes/mutasiGudang.js";
import subassemblyRouter from "./routes/subassembly.js";
import pemakaianMaterialRouter from "./routes/pemakaian-material.js";
import hasilProduksiHarianRouter from "./routes/hasil-produksi-harian.js";
import bomRouter from "./routes/bom.js";
import notificationsRouter from "./routes/notifications.js";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (_req, res) => {
  res.status(200).json({ message: "API berjalan" });
});

app.use("/api/auth", authRouter);
app.use("/api/admin", adminRouter);
app.use("/api/products", productsRouter);
app.use("/api/barang", barangRouter);
app.use("/api/variant-produk", variantProdukRouter);
app.use("/api/production-orders", productionOrdersRouter);
app.use("/api/styles", stylesRouter);
app.use("/api/colors", colorsRouter);
app.use("/api/sizes", sizesRouter);
app.use("/api/status-barang", statusBarangRouter);
app.use("/api/status-transition", statusTransitionRouter);
app.use("/api/barang-group", barangGroupRouter);
app.use("/api/integrasi-jurnal", integrasiJurnalRouter);
app.use("/api/karyawan", karyawanRouter);
app.use("/api/permintaan-barang", permintaanBarangRouter);
app.use("/api/divisi", divisiRouter);
app.use("/api/batches", batchesRouter);
app.use("/api/users", userRouter);
app.use("/api/roles", roleRouter);
app.use("/api/items", itemRouter);
app.use("/api/stok-opname", stokOpnameRouter);
app.use("/api/gudang", gudangRouter);
app.use("/api/mutasi-gudang", mutasiGudangRouter);
app.use("/api/subassemblies", subassemblyRouter);
app.use("/api/pemakaian-material", pemakaianMaterialRouter);
app.use("/api/pemakaian-materials", pemakaianMaterialRouter);
app.use("/api/hasil-produksi-harian", hasilProduksiHarianRouter);
app.use("/api/bom", bomRouter);
app.use("/api/notifications", notificationsRouter);


export default app;
