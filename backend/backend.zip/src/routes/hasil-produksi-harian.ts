import { Router } from "express";
import {
  createHasilProduksiHandler,
  getHasilProduksiHandler,
  getRekapHasilProduksiHandler,
  getWipPerItemHandler,
  listHasilProduksiHandler,
} from "../controller/hasilProduksiHarian/hasilProduksiHarian.js";
import { authenticate, authorize, requirePermission } from "../middleware/auth.js";

const router = Router();

router.use(authenticate);

router.post("/", authorize, requirePermission("KELOLA_ITEM"), createHasilProduksiHandler);

router.get("/", listHasilProduksiHandler);
// Daftarkan sebelum "/:id" supaya "rekap"/"wip" tidak tertangkap sebagai id.
router.get("/rekap", getRekapHasilProduksiHandler);
router.get("/wip", getWipPerItemHandler);
router.get("/:id", getHasilProduksiHandler);

export default router;
