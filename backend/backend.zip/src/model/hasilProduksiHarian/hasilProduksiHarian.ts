import prisma, { type PrismaTransactionClient } from "../../lib/prisma.js";
import { awalHariBisnis, tambahHariBisnis, tanggalBisnis } from "../../lib/tanggalBisnis.js";
import { Prisma } from "../../../generated/prisma/client.js";
import { TipeHasilProduksiItem, TipeStokItem } from "../../../generated/prisma/enums.js";
import { catatMutasi, getSaldo, lockItem, StokKurangError } from "../stokItem/stokItem.js";

export const DIVISI_TIDAK_DITEMUKAN = "DIVISI_TIDAK_DITEMUKAN";
export const ITEM_TIDAK_DITEMUKAN = "ITEM_TIDAK_DITEMUKAN";
export const INPUT_TIDAK_VALID = "INPUT_TIDAK_VALID";

export type HasilProduksiItemInput = {
  itemId: number;
  tipe: TipeHasilProduksiItem;
  jumlah: number;
  keterangan?: string | null;
};

export type HasilProduksiInput = {
  nomor?: string | null;
  tanggalProduksi?: Date | null;
  divisiId: number;
  keterangan?: string | null;
  items: HasilProduksiItemInput[];
};

export type HasilProduksiListParams = {
  page: number;
  limit: number;
  divisiId?: number;
  dari?: Date;
  sampai?: Date;
  q?: string;
};

export type HasilProduksiRekapParams = {
  dari?: Date;
  sampai?: Date;
  divisiId?: number;
  itemId?: number;
};

export type WipItemRow = {
  itemId: number;
  kode: string;
  nama: string;
  unit: string;
  jenis: string | null;
  divisiId: number | null;
  divisiNama: string | null;
  saldoAwal: number;
  masuk: number;
  keluar: number;
  saldoAkhir: number;
};

type RekapTipe = {
  masuk: number;
  keluar: number;
  hasil: number;
};

type RekapItem = RekapTipe & {
  itemId: number;
  itemKode: string;
  itemNama: string;
  satuan: string;
};

type RekapTanggal = RekapItem & {
  tanggal: string;
  divisiId: number;
  divisiNama: string;
};

type RekapDivisi = RekapItem & {
  divisiId: number;
  divisiNama: string;
};

export class HasilProduksiError extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = "HasilProduksiError";
    this.code = code;
  }
}

const itemSelect = {
  id: true,
  kode: true,
  nama: true,
  unit: true,
  jenis: true,
} as const;

const listInclude = {
  divisi: { select: { id: true, nama: true } },
  items: {
    orderBy: { id: "asc" as const },
    include: { item: { select: itemSelect } },
  },
} satisfies Prisma.HasilProduksiHarianInclude;

const detailInclude = {
  divisi: { select: { id: true, nama: true } },
  items: {
    orderBy: { id: "asc" as const },
    include: {
      item: { select: itemSelect },
      stokMutasi: { select: { id: true, tipe: true, jumlah: true, tanggal: true } },
    },
  },
} satisfies Prisma.HasilProduksiHarianInclude;

function tanggalPrefix(date: Date): string {
  return `HP-${tanggalBisnis(date).replaceAll("-", "")}-`;
}

function textOrNull(value: string | null | undefined): string | null {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  return text ? text : null;
}

function isTipeValid(value: unknown): value is TipeHasilProduksiItem {
  return (
    value === TipeHasilProduksiItem.MASUK ||
    value === TipeHasilProduksiItem.KELUAR ||
    value === TipeHasilProduksiItem.HASIL
  );
}

function isUniqueViolation(error: unknown): boolean {
  return (error as { code?: string } | null)?.code === "P2002";
}

function validasiInput(input: HasilProduksiInput): void {
  if (!Number.isInteger(input.divisiId) || input.divisiId <= 0) {
    throw new HasilProduksiError(INPUT_TIDAK_VALID, "Field 'divisiId' wajib angka bulat positif");
  }
  if (!Array.isArray(input.items) || input.items.length === 0) {
    throw new HasilProduksiError(INPUT_TIDAK_VALID, "Field 'items' wajib diisi minimal 1 item");
  }
  if (input.nomor !== undefined && input.nomor !== null && String(input.nomor).trim().length > 191) {
    throw new HasilProduksiError(INPUT_TIDAK_VALID, "Field 'nomor' maksimal 191 karakter");
  }
  if (
    input.tanggalProduksi !== undefined &&
    input.tanggalProduksi !== null &&
    (!(input.tanggalProduksi instanceof Date) || Number.isNaN(input.tanggalProduksi.getTime()))
  ) {
    throw new HasilProduksiError(INPUT_TIDAK_VALID, "Field 'tanggalProduksi' harus tanggal valid");
  }
  input.items.forEach((item, index) => {
    if (!item || !Number.isInteger(item.itemId) || item.itemId <= 0) {
      throw new HasilProduksiError(INPUT_TIDAK_VALID, `items[${index}].itemId wajib angka bulat positif`);
    }
    if (!isTipeValid(item.tipe)) {
      throw new HasilProduksiError(INPUT_TIDAK_VALID, `items[${index}].tipe harus MASUK, KELUAR, atau HASIL`);
    }
    if (!Number.isInteger(item.jumlah) || item.jumlah <= 0) {
      throw new HasilProduksiError(INPUT_TIDAK_VALID, `items[${index}].jumlah harus bilangan bulat lebih dari 0`);
    }
    if (item.jumlah > 2147483647) {
      throw new HasilProduksiError(INPUT_TIDAK_VALID, `items[${index}].jumlah terlalu besar`);
    }
  });

  if (input.items.some((item) => item.tipe === TipeHasilProduksiItem.KELUAR)) {
    const tipePerItem = new Map<number, Set<TipeHasilProduksiItem>>();
    for (const item of input.items) {
      const tipe = tipePerItem.get(item.itemId) ?? new Set<TipeHasilProduksiItem>();
      tipe.add(item.tipe);
      tipePerItem.set(item.itemId, tipe);
    }
    for (const [itemId, tipe] of tipePerItem) {
      if (tipe.has(TipeHasilProduksiItem.MASUK) && tipe.has(TipeHasilProduksiItem.KELUAR)) {
        throw new HasilProduksiError(
          INPUT_TIDAK_VALID,
          `Item ${itemId} tidak boleh memiliki baris MASUK dan KELUAR sekaligus`,
        );
      }
    }
  }
}

async function generateNomor(tx: PrismaTransactionClient, date: Date): Promise<string> {
  const prefix = tanggalPrefix(date);
  const terakhir = await tx.hasilProduksiHarian.findFirst({
    where: { nomor: { startsWith: prefix } },
    orderBy: { nomor: "desc" },
    select: { nomor: true },
  });
  const urut = terakhir ? Number(terakhir.nomor.slice(prefix.length)) + 1 : 1;
  return `${prefix}${String(urut).padStart(4, "0")}`;
}

async function createInTx(
  tx: PrismaTransactionClient,
  input: HasilProduksiInput,
  userId: number | null,
) {
  const tanggal = awalHariBisnis(input.tanggalProduksi ?? new Date());

  const divisi = await tx.divisi.findUnique({
    where: { id: input.divisiId },
    select: { id: true, nama: true },
  });
  if (!divisi) {
    throw new HasilProduksiError(DIVISI_TIDAK_DITEMUKAN, "Divisi tidak ditemukan");
  }

  const itemIds = [...new Set(input.items.map((item) => item.itemId))];
  const items = await tx.item.findMany({
    where: { id: { in: itemIds } },
    select: { id: true },
  });
  if (items.length !== itemIds.length) {
    const ada = new Set(items.map((item) => item.id));
    const hilang = itemIds.filter((id) => !ada.has(id));
    throw new HasilProduksiError(ITEM_TIDAK_DITEMUKAN, `Item tidak ditemukan: ${hilang.join(", ")}`);
  }

  const nomor = textOrNull(input.nomor) ?? (await generateNomor(tx, tanggal));

  const header = await tx.hasilProduksiHarian.create({
    data: {
      nomor,
      tanggalProduksi: tanggal,
      divisiId: input.divisiId,
      keterangan: textOrNull(input.keterangan),
      items: {
        create: input.items.map((item) => ({
          itemId: item.itemId,
          tipe: item.tipe,
          jumlah: item.jumlah,
          keterangan: textOrNull(item.keterangan),
        })),
      },
    },
    include: detailInclude,
  });

  // KELUAR = pengurangan stok. Lock per item dan cek total kebutuhan sekali,
  // supaya dua baris KELUAR untuk item yang sama tidak lolos cek saldo sendiri-sendiri.
  const keluarPerItem = new Map<number, number>();
  for (const item of input.items) {
    if (item.tipe !== TipeHasilProduksiItem.KELUAR) continue;
    keluarPerItem.set(item.itemId, (keluarPerItem.get(item.itemId) ?? 0) + item.jumlah);
  }
  for (const itemId of [...keluarPerItem.keys()].sort((a, b) => a - b)) {
    await lockItem(tx, itemId);
    const saldo = await getSaldo(itemId, tx);
    const butuh = keluarPerItem.get(itemId)!;
    if (butuh > saldo) throw new StokKurangError(itemId, saldo);
  }

  for (const detail of header.items) {
    if (detail.tipe === TipeHasilProduksiItem.MASUK) continue;
    await catatMutasi(tx, {
      itemId: detail.itemId,
      tipe: detail.tipe === TipeHasilProduksiItem.HASIL ? TipeStokItem.MASUK : TipeStokItem.KELUAR,
      jumlah: Number(detail.jumlah),
      sumberHasilProduksiItemId: detail.id,
      keterangan: `Produksi ${nomor} - ${divisi.nama}`,
      userId,
      tanggal,
    });
  }

  return tx.hasilProduksiHarian.findUniqueOrThrow({
    where: { id: header.id },
    include: detailInclude,
  });
}

export async function createHasilProduksi(input: HasilProduksiInput, userId: number | null = null) {
  validasiInput(input);
  const nomor = textOrNull(input.nomor);
  const normalized: HasilProduksiInput = { ...input, nomor };

  try {
    return await prisma.$transaction((tx) => createInTx(tx, normalized, userId));
  } catch (error) {
    // Nomor otomatis bisa bentrok saat dua request bersamaan. Nomor manual tidak
    // diulang otomatis supaya client tahu nomornya sudah dipakai.
    if (!nomor && isUniqueViolation(error)) {
      return prisma.$transaction((tx) => createInTx(tx, normalized, userId));
    }
    throw error;
  }
}

export async function listHasilProduksi(params: HasilProduksiListParams) {
  const where: Prisma.HasilProduksiHarianWhereInput = {};
  if (params.divisiId !== undefined) where.divisiId = params.divisiId;
  if (params.dari || params.sampai) {
    where.tanggalProduksi = {};
    if (params.dari) where.tanggalProduksi.gte = startOfDay(params.dari);
    if (params.sampai) where.tanggalProduksi.lt = startOfDay(addDays(params.sampai, 1));
  }
  const q = params.q?.trim();
  if (q) where.nomor = { contains: q };

  const [total, data] = await Promise.all([
    prisma.hasilProduksiHarian.count({ where }),
    prisma.hasilProduksiHarian.findMany({
      where,
      include: listInclude,
      orderBy: [{ tanggalProduksi: "desc" }, { id: "desc" }],
      skip: (params.page - 1) * params.limit,
      take: params.limit,
    }),
  ]);

  return {
    data,
    meta: {
      page: params.page,
      limit: params.limit,
      total,
      totalPages: Math.max(1, Math.ceil(total / params.limit)),
    },
  };
}

export async function getHasilProduksiById(id: number) {
  return prisma.hasilProduksiHarian.findUnique({
    where: { id },
    include: detailInclude,
  });
}

export async function getRekapHasilProduksi(params: HasilProduksiRekapParams) {
  const where: Prisma.HasilProduksiHarianItemWhereInput = {};
  if (params.itemId !== undefined) where.itemId = params.itemId;
  if (params.divisiId !== undefined || params.dari || params.sampai) {
    where.hasilProduksiHarian = {};
    if (params.divisiId !== undefined) where.hasilProduksiHarian.divisiId = params.divisiId;
    if (params.dari || params.sampai) {
      where.hasilProduksiHarian.tanggalProduksi = {};
      if (params.dari) where.hasilProduksiHarian.tanggalProduksi.gte = startOfDay(params.dari);
      if (params.sampai) {
        where.hasilProduksiHarian.tanggalProduksi.lt = startOfDay(addDays(params.sampai, 1));
      }
    }
  }

  const rows = await prisma.hasilProduksiHarianItem.findMany({
    where,
    select: {
      tipe: true,
      jumlah: true,
      item: { select: { id: true, kode: true, nama: true, unit: true } },
      hasilProduksiHarian: {
        select: {
          tanggalProduksi: true,
          divisi: { select: { id: true, nama: true } },
        },
      },
    },
    orderBy: { id: "asc" },
  });

  const perTanggal = new Map<string, RekapTanggal>();
  const perDivisi = new Map<string, RekapDivisi>();
  const perItem = new Map<number, RekapItem>();
  const total: RekapTipe = { masuk: 0, keluar: 0, hasil: 0 };

  for (const row of rows) {
    const jumlah = Number(row.jumlah);
    const tipe: keyof RekapTipe =
      row.tipe === TipeHasilProduksiItem.MASUK
        ? "masuk"
        : row.tipe === TipeHasilProduksiItem.KELUAR
          ? "keluar"
          : "hasil";
    total[tipe] += jumlah;

    const item = row.item;
    const divisi = row.hasilProduksiHarian.divisi;
    const tanggal = dayKey(row.hasilProduksiHarian.tanggalProduksi);
    const base = {
      itemId: item.id,
      itemKode: item.kode,
      itemNama: item.nama,
      satuan: item.unit,
      masuk: 0,
      keluar: 0,
      hasil: 0,
    };

    const keyTanggal = `${tanggal}|${divisi.id}|${item.id}`;
    let rowTanggal = perTanggal.get(keyTanggal);
    if (!rowTanggal) {
      rowTanggal = { ...base, tanggal, divisiId: divisi.id, divisiNama: divisi.nama };
      perTanggal.set(keyTanggal, rowTanggal);
    }
    rowTanggal[tipe] += jumlah;

    const keyDivisi = `${divisi.id}|${item.id}`;
    let rowDivisi = perDivisi.get(keyDivisi);
    if (!rowDivisi) {
      rowDivisi = { ...base, divisiId: divisi.id, divisiNama: divisi.nama };
      perDivisi.set(keyDivisi, rowDivisi);
    }
    rowDivisi[tipe] += jumlah;

    let rowItem = perItem.get(item.id);
    if (!rowItem) {
      rowItem = { ...base };
      perItem.set(item.id, rowItem);
    }
    rowItem[tipe] += jumlah;
  }

  const byNama = (a: RekapItem, b: RekapItem) =>
    a.itemNama.localeCompare(b.itemNama) || a.itemId - b.itemId;

  return {
    perTanggal: [...perTanggal.values()].sort(
      (a, b) =>
        a.tanggal.localeCompare(b.tanggal) ||
        a.divisiNama.localeCompare(b.divisiNama) ||
        a.itemNama.localeCompare(b.itemNama),
    ),
    perDivisi: [...perDivisi.values()].sort(
      (a, b) => a.divisiNama.localeCompare(b.divisiNama) || byNama(a, b),
    ),
    perItem: [...perItem.values()].sort(byNama),
    total,
  };
}

export async function getWipPerItem(params: HasilProduksiRekapParams): Promise<WipItemRow[]> {
  const itemWhere: Prisma.ItemWhereInput = {};
  if (params.divisiId !== undefined) itemWhere.divisiId = params.divisiId;
  if (params.itemId !== undefined) itemWhere.id = params.itemId;

  const awal = params.dari ? startOfDay(params.dari) : null;
  const akhir = params.sampai ? startOfDay(addDays(params.sampai, 1)) : null;

  const [openingRows, periodRows] = await Promise.all([
    prisma.stokItemMutasi.groupBy({
      by: ["itemId", "tipe"],
      where: { item: itemWhere, tanggal: { lt: awal ?? new Date(0) } },
      _sum: { jumlah: true },
    }),
    prisma.stokItemMutasi.groupBy({
      by: ["itemId", "tipe"],
      where: {
        item: itemWhere,
        ...(awal || akhir
          ? {
              tanggal: {
                ...(awal ? { gte: awal } : {}),
                ...(akhir ? { lt: akhir } : {}),
              },
            }
          : {}),
      },
      _sum: { jumlah: true },
    }),
  ]);

  const agg = new Map<number, { saldoAwal: number; masuk: number; keluar: number }>();
  const bucket = (itemId: number) => {
    let row = agg.get(itemId);
    if (!row) {
      row = { saldoAwal: 0, masuk: 0, keluar: 0 };
      agg.set(itemId, row);
    }
    return row;
  };

  for (const row of openingRows) {
    const jumlah = row._sum.jumlah ?? 0;
    const target = bucket(row.itemId);
    target.saldoAwal += row.tipe === TipeStokItem.MASUK ? jumlah : -jumlah;
  }
  for (const row of periodRows) {
    const jumlah = row._sum.jumlah ?? 0;
    const target = bucket(row.itemId);
    if (row.tipe === TipeStokItem.MASUK) target.masuk += jumlah;
    else target.keluar += jumlah;
  }

  if (agg.size === 0) return [];

  const items = await prisma.item.findMany({
    where: { id: { in: [...agg.keys()] } },
    select: {
      id: true,
      kode: true,
      nama: true,
      unit: true,
      jenis: true,
      divisi: { select: { id: true, nama: true } },
    },
  });

  return items
    .map((item) => {
      const row = agg.get(item.id)!;
      return {
        itemId: item.id,
        kode: item.kode,
        nama: item.nama,
        unit: item.unit,
        jenis: item.jenis,
        divisiId: item.divisi?.id ?? null,
        divisiNama: item.divisi?.nama ?? null,
        saldoAwal: row.saldoAwal,
        masuk: row.masuk,
        keluar: row.keluar,
        saldoAkhir: row.saldoAwal + row.masuk - row.keluar,
      };
    })
    .sort((a, b) => a.nama.localeCompare(b.nama) || a.itemId - b.itemId);
}
