import { Prisma } from "../../../generated/prisma/client.js";
import prisma from "../../lib/prisma.js";
import {
  BARANG_TTL_STATS,
  barangScopeKey,
  barangStatsKey,
  getBarangCache,
  setBarangCache,
} from "../../lib/barangCache.js";
import { statusScopeFilter, type StatusFilter } from "./barang.status.js";


export type FinishgoodPerBulanRow = {
  bulan: string;
  tahun: number;
  bulanAngka: number;
  variantId: number;
  productId: number;
  jumlah: number;
};

export type FinishgoodPerBulanFilter = {
  variantId?: number;
  productId?: number;
  tanggalAwal?: Date;
  tanggalAkhir?: Date;
};

type StatusGroup = { status: string; _count: { _all: number } };
type VariantGroup = { variantId: number; _count: { _all: number } };
type BatchGroup = { batchId: number | null; _count: { _all: number } };
type VariantDetails = {
  id: number;
  product: { nama: string };
  style: { nama: string };
  color: { nama: string };
  size: { nama: string };
};
type BatchDetails = { id: number; nomorBatch: number };

export async function getStatusSummary(statusScope?: string[] | null): Promise<{
  total: number;
  perStatus: Record<string, number>;
}> {
  const cacheKey = barangStatsKey("status-summary", { scope: barangScopeKey(statusScope) });
  const cached = await getBarangCache<{ total: number; perStatus: Record<string, number> }>(cacheKey);
  if (cached) return cached;

  const statusFilter = statusScopeFilter(statusScope);
  const groups = await prisma.barang.groupBy({
    by: ["status"],
    where: statusFilter ? { status: statusFilter } : {},
    _count: { _all: true },
    orderBy: { status: "asc" },
  });

  const statusRows = await prisma.statusBarang.findMany({ select: { kode: true }, orderBy: { urutan: "asc" } });
  const visible = new Set<string>(statusScope ?? statusRows.map((s) => s.kode));
  const perStatus: Record<string, number> = {};
  for (const s of statusRows) if (visible.has(s.kode)) perStatus[s.kode] = 0;

  let total = 0;
  for (const group of groups) {
    const status = group.status;
    const count = (group._count as { _all: number })._all ?? 0;
    perStatus[status] = count;
    total += count;
  }

  const result = { total, perStatus };
  await setBarangCache(cacheKey, result, BARANG_TTL_STATS);
  return result;
}

export async function getBarangStats(filter: {
  variantId?: number;
  batchId?: number;
}, statusScope?: string[] | null): Promise<{
  total: number;
  perStatus: Record<string, number>;
  perVariant: { variantId: number; nama: string; total: number }[];
  perBatch: { batchId: number; nomorBatch: string; total: number }[];
}> {
  const cacheKey = barangStatsKey("stats", {
    ...filter,
    scope: barangScopeKey(statusScope),
  });
  const cachedStats = await getBarangCache<Awaited<ReturnType<typeof getBarangStatsUncached>>>(cacheKey);
  if (cachedStats) return cachedStats;

  const result = await getBarangStatsUncached(filter, statusScope);
  await setBarangCache(cacheKey, result, BARANG_TTL_STATS);
  return result;
}

async function getBarangStatsUncached(filter: {
  variantId?: number;
  batchId?: number;
}, statusScope?: string[] | null): Promise<{
  total: number;
  perStatus: Record<string, number>;
  perVariant: { variantId: number; nama: string; total: number }[];
  perBatch: { batchId: number; nomorBatch: string; total: number }[];
}> {
  const statusFilter = statusScopeFilter(statusScope);
  const where: { variantId?: number; batchId?: number; status?: StatusFilter } = {};
  if (filter.variantId !== undefined) where.variantId = filter.variantId;
  if (filter.batchId !== undefined) where.batchId = filter.batchId;
  if (statusFilter) where.status = statusFilter;

  const visibleNonRegister = statusScope?.filter((s) => s !== "REGISTER");
  const batchWhere: {
    variantId?: number;
    batchId?: number;
    status?: StatusFilter;
  } = {
    status: visibleNonRegister ? { in: visibleNonRegister } : { not: "REGISTER" },
  };
  if (filter.variantId !== undefined) batchWhere.variantId = filter.variantId;
  if (filter.batchId !== undefined) batchWhere.batchId = filter.batchId;

  const [statusGroups, variantGroups, batchGroups, totalCount] =
    (await prisma.$transaction([
      prisma.barang.groupBy({
        by: ["status"],
        where,
        _count: { _all: true },
        orderBy: { status: "asc" },
      }),
      prisma.barang.groupBy({
        by: ["variantId"],
        where,
        _count: { _all: true },
        orderBy: { variantId: "asc" },
      }),
      prisma.barang.groupBy({
        by: ["batchId"],
        where: batchWhere,
        _count: { _all: true },
        orderBy: { batchId: "asc" },
      }),
      prisma.barang.count({ where }),
    ])) as [StatusGroup[], VariantGroup[], BatchGroup[], number];

  const statusRows2 = await prisma.statusBarang.findMany({ select: { kode: true }, orderBy: { urutan: "asc" } });
  const visible2 = new Set<string>(statusScope ?? statusRows2.map((s) => s.kode));
  const perStatus: Record<string, number> = {};
  for (const s of statusRows2) if (visible2.has(s.kode)) perStatus[s.kode] = 0;

  for (const group of statusGroups) {
    perStatus[group.status] = (group._count as { _all: number })._all ?? 0;
  }

  const variantIds = variantGroups.map((group) => group.variantId);
  const variants: VariantDetails[] = await prisma.productVariant.findMany({
    where: { id: { in: variantIds } },
    include: { product: true, style: true, color: true, size: true },
  });

  const variantMap = new Map<number, string>(
    variants.map((variant) => [
      variant.id,
      `${variant.product.nama} - ${variant.style.nama} - ${variant.color.nama} - ${variant.size.nama}`,
    ]),
  );

  const perVariant = variantGroups
    .map((group) => ({
      variantId: group.variantId,
      nama: variantMap.get(group.variantId) ?? `V${group.variantId}`,
      total: (group._count as { _all: number })._all ?? 0,
    }))
    .sort((a, b) => b.total - a.total);

  const batchIds = batchGroups.map((group) => group.batchId).filter((id): id is number => id !== null);
  const batches: BatchDetails[] = await prisma.productionBatch.findMany({
    where: { id: { in: batchIds } },
    select: { id: true, nomorBatch: true },
  });

  const batchMap = new Map<number, number>(
    batches.map((batch) => [batch.id, batch.nomorBatch]),
  );

  const perBatch = batchGroups
    .filter((group) => group.batchId !== null)
    .map((group) => ({
      batchId: group.batchId as number,
      nomorBatch: `BC${String(batchMap.get(group.batchId!) ?? 0).padStart(3, "0")}`,
      total: (group._count as { _all: number })._all ?? 0,
    }))
    .sort((a, b) => b.total - a.total);

  return { total: totalCount, perStatus, perVariant, perBatch };
}

/** Bangun WHERE clause parameterized dari filter query params */
function buildFinishgoodWhere(filter: FinishgoodPerBulanFilter): Prisma.Sql {
  const conditions: Prisma.Sql[] = [Prisma.sql`1 = 1`];

  if (filter.variantId !== undefined) conditions.push(Prisma.sql`v.variantId = ${filter.variantId}`);
  if (filter.productId !== undefined) conditions.push(Prisma.sql`v.productId = ${filter.productId}`);
  if (filter.tanggalAwal !== undefined) conditions.push(Prisma.sql`v.bulan >= ${formatBulanKey(filter.tanggalAwal)}`);
  if (filter.tanggalAkhir !== undefined) conditions.push(Prisma.sql`v.bulan <= ${formatBulanKey(filter.tanggalAkhir)}`);

  return Prisma.join(conditions, " AND ");
}

/** Format Date menjadi key bulan "YYYY-MM" untuk dibandingkan dengan kolom view */
function formatBulanKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  return `${y}-${m}`;
}

export async function getFinishgoodPerBulan(
  filter: FinishgoodPerBulanFilter = {},
): Promise<{
  data: FinishgoodPerBulanRow[];
  meta: { variantId?: number; productId?: number };
}> {
  const cacheKey = barangStatsKey("finishgood-per-bulan", {
    variantId: filter.variantId ?? "",
    productId: filter.productId ?? "",
    tanggalAwal: filter.tanggalAwal?.toISOString() ?? "",
    tanggalAkhir: filter.tanggalAkhir?.toISOString() ?? "",
  });
  const cached = await getBarangCache<{
    data: FinishgoodPerBulanRow[];
    meta: { variantId?: number; productId?: number };
  }>(cacheKey);
  if (cached) return cached;

  const where = buildFinishgoodWhere(filter);

  const rows = await prisma.$queryRaw<FinishgoodPerBulanRow[]>`
    SELECT v.bulan, v.tahun, v.bulanAngka, v.variantId, v.productId, v.jumlah
    FROM ViewBarangFinishgoodPerBulan v
    WHERE ${where}
    ORDER BY v.tahun ASC, v.bulanAngka ASC, v.variantId ASC`;

  const data = rows.map((row: FinishgoodPerBulanRow) => ({ ...row, jumlah: Number(row.jumlah) }));

  const result = { data, meta: { variantId: filter.variantId, productId: filter.productId } };
  await setBarangCache(cacheKey, result, BARANG_TTL_STATS);
  return result;
}

// =============================================
// Rentang tanggal per batch (SELESAI & AKTIF)
// =============================================

export type BatchRentangFilter = {
  tanggalAwal?: Date;
  tanggalAkhir?: Date;
};

export type BatchRentangRow = {
  batchId: number;
  nomorBatch: string;
  jumlah: number;
  tanggalMulai: Date | null;
  tanggalSelesai: Date | null;
};

type BatchRentangRawRow = {
  batchId: number;
  nomorBatch: number;
  totalProduksi: number;
  jumlahNonRegister: bigint | number | null;
  tanggalMulai: Date | null;
  tanggalSelesai: Date | null;
};

function formatNomorBatch(nomor: number): string {
  return `BC${String(nomor).padStart(3, "0")}`;
}

function buildBatchRentangWhere(
  filter: BatchRentangFilter,
  column: "tanggalMulai" | "tanggalSelesai",
): Prisma.Sql {
  const conditions: Prisma.Sql[] = [Prisma.sql`1 = 1`];
  if (filter.tanggalAwal !== undefined) conditions.push(Prisma.sql`v.${Prisma.raw(column)} >= ${filter.tanggalAwal}`);
  if (filter.tanggalAkhir !== undefined) conditions.push(Prisma.sql`v.${Prisma.raw(column)} <= ${filter.tanggalAkhir}`);
  return Prisma.join(conditions, " AND ");
}

export async function getBatchRentangTanggal(
  filter: BatchRentangFilter = {},
): Promise<{
  selesai: BatchRentangRow[];
  aktif: BatchRentangRow[];
}> {
  const cacheKey = barangStatsKey("batch-rentang", {
    tanggalAwal: filter.tanggalAwal?.toISOString() ?? "",
    tanggalAkhir: filter.tanggalAkhir?.toISOString() ?? "",
  });
  const cached = await getBarangCache<{
    selesai: BatchRentangRow[];
    aktif: BatchRentangRow[];
  }>(cacheKey);
  if (cached) {
    return {
      selesai: cached.selesai.map((r) => ({ ...r, tanggalMulai: r.tanggalMulai ? new Date(r.tanggalMulai) : null, tanggalSelesai: r.tanggalSelesai ? new Date(r.tanggalSelesai) : null })),
      aktif: cached.aktif.map((r) => ({ ...r, tanggalMulai: r.tanggalMulai ? new Date(r.tanggalMulai) : null, tanggalSelesai: r.tanggalSelesai ? new Date(r.tanggalSelesai) : null })),
    };
  }

  const [selesaiRows, aktifRows] = await prisma.$transaction([
    prisma.$queryRaw<BatchRentangRawRow[]>`
      SELECT v.batchId, v.nomorBatch, v.jumlahNonRegister, v.tanggalMulai, v.tanggalSelesai
      FROM ViewBatchRentangTanggal v
      WHERE v.status = 'SELESAI' AND ${buildBatchRentangWhere(filter, "tanggalSelesai")}
      ORDER BY v.tanggalSelesai ASC, v.nomorBatch ASC`,
    prisma.$queryRaw<BatchRentangRawRow[]>`
      SELECT v.batchId, v.nomorBatch, v.jumlahNonRegister, v.tanggalMulai, v.tanggalSelesai
      FROM ViewBatchRentangTanggal v
      WHERE v.status = 'AKTIF' AND ${buildBatchRentangWhere(filter, "tanggalMulai")}
      ORDER BY v.nomorBatch ASC`,
  ]);

  const mapRow = (row: BatchRentangRawRow, endDate: Date | null): BatchRentangRow => ({
    batchId: row.batchId,
    nomorBatch: formatNomorBatch(row.nomorBatch),
    jumlah: Number(row.jumlahNonRegister ?? 0),
    tanggalMulai: row.tanggalMulai ? new Date(row.tanggalMulai) : null,
    tanggalSelesai: endDate
      ? new Date(endDate)
      : row.tanggalSelesai
        ? new Date(row.tanggalSelesai)
        : null,
  });

  const selesai = selesaiRows.map((row: BatchRentangRawRow) => mapRow(row, row.tanggalSelesai));
  const aktif = aktifRows.map((row: BatchRentangRawRow) => mapRow(row, new Date()));

  const result = { selesai, aktif };
  await setBarangCache(cacheKey, result, BARANG_TTL_STATS);
  return result;
}
