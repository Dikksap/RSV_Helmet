# Dokumentasi API — RSV Helmet Backend

> **Untuk siapa:** agent AI lain / project lain (frontend, integrasi eksternal) yang mau konsumsi API ini tanpa baca seluruh source.
> **Source of truth:** `src/routes/*` (method+path+middleware), controller (`src/controller/*`) untuk validasi/status, `prisma/schema.prisma` untuk model/constraint, `tests/*.test.ts` untuk perilaku yang diasumsikan stabil.
> Jika doc ini bentrok dengan source → source menang.
>
> **Base URL:** `http://localhost:8000` (dev). Port dari `PORT` env, default `8000` (`api/index.ts:8`, `.env.example:5`). Doc lama tulis `3000` — itu stale, jangan pakai.
> **Stack:** Node.js + TypeScript + Express (ESM), Prisma 7 + `@prisma/adapter-mariadb` (MySQL/MariaDB), JWT + bcryptjs, Redis (cache + JWT blacklist + pub/sub), `ws` WebSocket.
> **Entry:** `src/app.ts` mount router, `api/index.ts` runtime (HTTP+WS, kecuali `VERCEL=1`). Import lokal TS wajib ekstensi `.js`.

## Daftar Isi
- [0. Quick Contract (baca ini dulu)](#0-quick-contract-baca-ini-dulu)
- [1. Setup Konsumen](#1-setup-konsumen)
- [2. Konvensi Umum](#2-konvensi-umum)
- [3. Auth](#3-auth)
- [4. Admin](#4-admin)
- [5. Product](#5-product)
- [6. Variant Produk Standalone](#6-variant-produk-standalone)
- [7. Style / Color / Size](#7-style--color--size-master-referensi)
- [8. Barang](#8-barang)
  - [8.8 Production Order (Master Produksi)](#88-production-order-master-produksi)
- [9. WebSocket Realtime](#9-websocket-realtime)
- [10. Domain Model & Aturan Bisnis](#10-domain-model--aturan-bisnis)
- [11. Error & Status Code](#11-error--status-code)
- [12. Resep Integrasi](#12-resep-integrasi-untuk-project-lain)
- [13. Contoh cURL](#13-contoh-curl)
- [14. File Referensi](#14-file-referensi)

---

## 0. Quick Contract (baca ini dulu)

### 0.1 Semua endpoint (verified dari `src/routes/*`, `src/app.ts`)

| Method | Path | Auth | Keterangan |
|--------|------|------|------------|
| GET | `/` | — | Health `{ message: "API berjalan" }` |
| POST | `/api/auth/login` | — | Login → JWT |
| POST | `/api/auth/logout` | Bearer wajib | Blacklist token |
| GET | `/api/admin/dashboard` | Bearer + admin | Echo `{ message, user }` |
| GET | `/api/products` | — | List + variants |
| GET | `/api/products/:id` | — | Detail |
| POST | `/api/products` | — | `{ nama, prefix }` |
| PUT | `/api/products/:id` | — | `{ nama }` |
| DELETE | `/api/products/:id` | — | Cascade variant |
| GET | `/api/products/:id/variants` | — | Variant milik product |
| POST | `/api/products/:id/variants` | — | `{ styleId, colorId, sizeId, tanggal? }` |
| PATCH | `/api/products/:id/variants/:variantId` | — | `{ tanggal? }` |
| DELETE | `/api/products/:id/variants/:variantId` | — | Hapus variant |
| GET | `/api/variant-produk` | — | List + filter `productId,styleId,colorId,sizeId` |
| GET | `/api/variant-produk/:id` | — | Detail |
| POST | `/api/variant-produk` | — | `{ productId, styleId, colorId, sizeId, tanggal? }` |
| PUT | `/api/variant-produk/:id` | — | Parsial, min 1 field |
| DELETE | `/api/variant-produk/:id` | — | Hapus variant |
| GET | `/api/styles` | — | List |
| GET | `/api/styles/:id` | — | Detail |
| POST | `/api/styles` | — | `{ nama }` |
| PUT | `/api/styles/:id` | — | `{ nama }` |
| DELETE | `/api/styles/:id` | — | 409 jika dipakai variant |
| GET/… | `/api/colors`, `/api/sizes` | — | Pola sama dengan styles (sizes ada field `urutan?`) |
| GET | `/api/barang/generate-info?variantId=` | Bearer + `BARANG_GENERATE` | Info batch + nextNumber |
| POST | `/api/barang/generate` | Bearer + `BARANG_GENERATE` | `{ variantId, jumlah }` 1..50000 |
| POST | `/api/barang` | Bearer + `BARANG_KELOLA` | Create single |
| GET | `/api/barang` | Bearer + `BARANG_LIHAT` + scope status | List + filter + pagination; `?status=` di luar scope → 403; filter `gudangId` / `tanpaGudang=true`; respons sertakan `gudang {id,kode,name}` |
| GET | `/api/barang/hari-ini` | Bearer + `BARANG_LIHAT` + scope | Barang tanggal hari ini (shortcut `?tanggal=<today>`) |
| GET | `/api/barang/status-summary` | Bearer + `BARANG_STATISTIK_LIHAT` + scope | `{ total, perStatus }` |
| GET | `/api/barang/summary` | Bearer + `BARANG_STATISTIK_LIHAT` + scope | Alias status-summary |
| GET | `/api/barang/stats?variantId=&batchId=` | Bearer + `BARANG_STATISTIK_LIHAT` + scope | `{ total, perStatus, perVariant, perBatch }` |
| GET | `/api/barang/batch-rentang-tanggal` | Bearer + `BARANG_STATISTIK_LIHAT` | Filter tanggal batch |
| GET | `/api/barang/finishgood-per-bulan` | Bearer + `BARANG_STATISTIK_LIHAT` | Group `YYYY-MM` |
| GET | `/api/barang/search?q=&limit=` | Bearer + `BARANG_LIHAT` + scope | LIKE kodeBarang |
| GET | `/api/barang/export?format=` | Bearer + `BARANG_LIHAT` + scope | `json`\|`csv` |
| GET | `/api/barang/scan/:kodeBarang` | Bearer + `BARANG_SCAN` + scope | Scan single by barcode |
| POST | `/api/barang/scan/bulk` | Bearer + `BARANG_SCAN` + `BARANG_UBAH_STATUS` | `{ kodeBarang[], status, keterangan? }` |
| POST | `/api/barang/bulk-status` | Bearer + `BARANG_UBAH_STATUS` | `{ items: [{id,status,keterangan?}] }` max 500 |
| PUT | `/api/barang/:id` | Bearer + `BARANG_KELOLA` | Update parsial |
| DELETE | `/api/barang/:id` | Bearer + `BARANG_KELOLA` | Hapus + decrement batch |
| PATCH | `/api/barang/:id/status` | Bearer + `BARANG_UBAH_STATUS` | `{ status, keterangan? }` |
| GET | `/api/barang/:id/riwayat` | Bearer + `BARANG_LIHAT` + scope | `{ data[], summary }`; status di luar scope → 403 |
| GET | `/api/barang/:id` | Bearer + `BARANG_LIHAT` + scope | Detail, status di luar scope → 403 (paling akhir agar tidak telan route di atas) |
| GET | `/api/roles`, `/api/roles/:id` | Bearer + `ROLE_KELOLA` | Lihat RBAC (lihat §4.5) |
| POST | `/api/roles` | Bearer + `ROLE_KELOLA` | `{ kode, nama }` |
| GET | `/api/roles/permissions` | Bearer + `ROLE_KELOLA` | Permission master |
| PUT | `/api/roles/:id/permissions` | Bearer + `ROLE_KELOLA` | Replace grant `{ permissions[] }` |
| PUT | `/api/roles/:id/barang-status` | Bearer + `ROLE_KELOLA` | Replace matriks `{ statusView }` |
| GET | `/api/auth/me` | Bearer | `user` + `permissions[]` + `statusView[]` |
| GET | `/api/items?q=&divisiId=&aktif=` | publik | Master item (dropdown form permintaan) |
| GET | `/api/items/:id` | publik | Detail + divisi |
| POST | `/api/items` | Bearer + admin | `{ kode, nama, divisiId?, unit?, isActive? }` → 409 kode duplikat |
| PUT | `/api/items/:id` | Bearer + admin | Parsial → 404/409 |
| DELETE | `/api/items/:id` | Bearer + admin | Rincian permintaan ikut SetNull, snapshot utuh |
| GET | `/api/gudang` | Bearer | List + `_count.barang` ter-scope status |
| GET | `/api/gudang/:id` | Bearer | Detail + `_count` |
| POST | `/api/gudang` | Bearer + admin | `{ kode, name, isActive? }` → 409 |
| PUT | `/api/gudang/:id` | Bearer + admin | Parsial → 404/409 |
| DELETE | `/api/gudang/:id` | Bearer + admin | Barang ikut SetNull, riwayat utuh |
| GET | `/api/mutasi-gudang?barangId=&kodeBarang=&gudangId=&dari=&sampai=` | Bearer + `BARANG_LIHAT` | List + pagination |
| GET | `/api/mutasi-gudang/barang/:barangId` | Bearer + `BARANG_LIHAT` | Riwayat per barang |
| GET | `/api/mutasi-gudang/gudang/:gudangId` | Bearer + `BARANG_LIHAT` | Riwayat per gudang |
| POST | `/api/mutasi-gudang` | Bearer + `MUTASI_GUDANG` | `{ barangId\|kodeBarang, gudangAsalId?, gudangTujuanId?, keterangan? }`, `userId` dari token, atomik |
| POST | `/api/mutasi-gudang/bulk` | Bearer + `MUTASI_GUDANG` | `{ barangIds[] (maks 500), gudangTujuanId \| null, keterangan? }` — satu tujuan, asal otomatis dari lokasi kini, all-or-nothing dalam satu transaksi |
| GET | `/api/production-orders` | — | List header + `_count.items`, tanpa pagination/filter |
| GET | `/api/production-orders/:id?summary=1` | — | Detail + items; `summary=1` menambah `ringkasan` |
| POST | `/api/production-orders` | — | `{ nomor, periode, label?, status?, items? }` |
| PUT | `/api/production-orders/:id` | — | Update parsial header, bukan items |
| DELETE | `/api/production-orders/:id` | — | Hapus order + cascade items |
| POST | `/api/production-orders/:id/items` | — | `{ variantId, qty, priority? }` |
| PUT | `/api/production-orders/:id/items/:itemId` | — | Parsial `{ qty?, priority? }` + hitung ulang total |
| DELETE | `/api/production-orders/:id/items/:itemId` | — | Hapus item + hitung ulang total order |
| GET | `/api/production-orders/:id/capacities` | — | List kapasitas per tahap (`urutan,id` asc) |
| PUT | `/api/production-orders/:id/capacities` | — | Replace-all kapasitas, body array |
| GET | `/api/production-orders/:id/schedule?prep=&qc=` | — | Jadwal otomatis (fungsi murni, tanpa tabel) |

### 0.2 Auth matrix

| Endpoint | Middleware (`src/routes/*.ts`) |
|----------|-------------------------------|
| `POST /api/auth/logout`, `GET /api/auth/me` | `authenticate` (+ `authorize` untuk `/me`) (`src/routes/auth.ts`) |
| `GET /api/admin/dashboard` | `authenticate` + `adminOnly` (`src/routes/admin.ts`) |
| `GET /api/barang*` | `authenticate` + `authorize` + `requirePermission(...)` per endpoint (lihat §4.5) |
| `GET /api/barang-group*` | `authenticate` + `authorize` + `requireRole("admin","user")` |
| `GET /api/roles*` | `authenticate` + `authorize` + `requirePermission("ROLE_KELOLA")` |
| `GET /api/users*` | `authenticate` + `adminOnly` |
| Hampir semua router lain | `authenticate`; write (POST/PUT/PATCH/DELETE) + `adminOnly` kecuali yang eksplisit lain (lihat `src/middleware/auth.ts` + tiap `src/routes/*.ts`) |
| Pengecualian publik | `POST /api/auth/login`, `POST /api/permintaan-barang`, `GET /api/status-barang` |

### 0.3 Enum yang harus di-hardcode di konsumen

```ts
type StatusBarang = "REGISTER" | "FINISHGOOD" | "RETUR" | "OUT" | "BAD";
type StatusBatch = "AKTIF" | "SELESAI";
type StatusProductionOrder = "DRAFT" | "AKTIF" | "SELESAI" | "BATAL";
// Transisi valid (src/model/barang/barang.status.ts:14):
// REGISTER   -> FINISHGOOD | OUT | RETUR | BAD
// FINISHGOOD -> OUT | RETUR | BAD
// RETUR      -> FINISHGOOD | OUT | BAD
// OUT       -> RETUR
// BAD       -> FINISHGOOD
// PENTING: same-status (X->X) DITOLAK di POST /scan/bulk,
//           DITERIMA di PATCH /:id/status dan POST /bulk-status.
```

### 0.4 Yang TIDAK ada (jangan diasumsikan)

- Tidak ada register endpoint publik (user dibuat admin via `POST /api/users` dengan role dari tabel `Role`).
- Tidak ada MQTT / RFID / IoT / EPC di repo ini. Jangan bikin topic/payload IoT.
- Tidak ada endpoint update status ProductVariant; field status variant sudah tidak ada di schema.
- Tidak ada pagination di `GET /api/products` dan `GET /api/variant-produk`.
- `GET /api/production-orders` tanpa pagination/filter; `PUT /:id` tidak menyentuh items/`totalQty`; write production-order tidak emit event WS dan tidak pakai cache Redis.

---

## 1. Setup Konsumen

```bash
# env minimal (lihat .env.example)
PORT=8000
DATABASE_URL="mysql://root:@localhost:3306/express_api"
REDIS_URL=redis://localhost:6379
JWT_SECRET=ganti-dengan-secret-acak-yang-panjang
JWT_EXPIRES_IN=8h
TZ=Asia/Jakarta

npm run dev        # tsx watch api/index.ts
npm run build      # tsc
npm test           # vitest run
npm run docker:up  # mysql+redis
npm run db:seed    # seed style/color/size awal
```

### Seed Production Order (Docker)

```bash
docker exec backend-api-1 npx tsx prisma/seed-production-order.ts
```

- Seed baca `DB_HOST/DB_PORT/DB_USER/DB_PASSWORD/DB_NAME`, bukan `DATABASE_URL` (`prisma/seed-production-order.ts:6-13`). Jalan di dalam container agar host DB Docker (`db`) resolve. Detail isi + perilaku upsert: [8.8](#88-production-order-master-produksi).

- `GET /` → `200 { message: "API berjalan" }` (`src/app.ts:22`).
- CORS global `cors()`, body `express.json()` + `urlencoded` (`src/app.ts:18-20`).
- Vercel (`VERCEL=1`): WS tidak diinisialisasi, hanya HTTP (`api/index.ts:12`).

---

## 2. Konvensi Umum

| Aspek | Detail |
|-------|--------|
| **Content-Type** | `application/json` kecuali `GET /api/barang/export?format=csv` → `text/csv` |
| **JWT** | `Authorization: Bearer <token>`, payload `{ id, email, name, role, iat, exp }` (`src/lib/jwt.ts:7`), expiry default `8h`, secret fallback `""` (jangan anggap aman) |
| **Blacklist** | Redis via `src/lib/tokenBlacklist.ts`; `authenticate` cek `isTokenRevoked`; Redis fail-open |
| **Validasi** | Manual di controller, tanpa library eksternal |
| **ID path** | Numerik `Number(param)`; NaN → `400` |
| **Tanggal query** | `YYYY-MM-DD`; `tanggalAwal` → start-of-day UTC, `tanggalAkhir` → end-of-day UTC; `tanggalAwal > tanggalAkhir` → `400` |
| **Cache** | Product list 60 dtk (Redis); barang list/search/stats di-cache, di-invalidate tiap write (`clearBarangCache`) |

---

## 3. Auth
Route `src/routes/auth.ts`, controller `src/controller/auth/auth.ts:7`, model `src/model/user/user.ts`.

### POST /api/auth/login
```json
// request
{ "email": "user@example.com", "password": "secret123" }
// 200
{ "message": "Login berhasil", "token": "<jwt>",
  "user": { "id": 1, "name": "Admin", "email": "a@b.com", "role": "admin" } }
```
- `email`/`password` wajib string truthy → `400 { message: "Field 'email' wajib diisi" }` (atau password).
- User tidak ada / password salah → `401 { message: "Email atau password salah" }`; error lain `500 { message: "Gagal login" }`.
- Flow: `findUserByEmail` → `bcrypt.compare` → `signToken({id,email,name,role})` (`src/controller/auth/auth.ts:31`).

### POST /api/auth/logout
- Auth `authenticate` wajib. Token diambil dari header, di-blacklist sampai `exp` (`revokeToken(token, req.user.exp)`).
- `200 { message: "Logout berhasil" }`.
- `401`: `Token tidak ditemukan` (header hilang), `Token sudah logout` (revoked), `Token tidak valid atau kedaluwarsa`.

---

## 4. Admin

### GET /api/admin/dashboard
- `authenticate` + `adminOnly` (`role === "admin"`, else `403 { message: "Akses ditolak. Memerlukan akses admin." }`).
- `200 { message: "Admin dashboard", user: { id, email, name, role, iat, exp } }`.

---

## 4.5 Role & Permission (RBAC barang)

Router `src/routes/role.ts`, controller `src/controller/role/role.ts`, model `src/model/role/role.ts`, middleware `authorize` + `requirePermission` di `src/middleware/auth.ts`.

Matriks akses disimpan di database (`Role`, `Permission`, `RolePermission`, `RoleBarangStatusPermission`); `ADMIN` melewati matriks dan selalu melihat semua status. Kode role/permission dinormalisasi (input case-insensitive, disimpan canonical).

| Endpoint | Auth | Deskripsi |
|----------|------|-----------|
| GET `/api/roles` | Bearer + `ROLE_KELOLA` | List role + grant permission + matriks status |
| POST `/api/roles` | Bearer + `ROLE_KELOLA` | `{ kode, nama }` → 201 / 400 kode invalid / 409 duplikat |
| GET `/api/roles/permissions` | Bearer + `ROLE_KELOLA` | Permission master |
| GET `/api/roles/:id` | Bearer + `ROLE_KELOLA` | Detail role → 404 jika tidak ada |
| PUT `/api/roles/:id/permissions` | Bearer + `ROLE_KELOLA` | `{ permissions: string[] }` replace grant → 400 kode asing / 404 |
| PUT `/api/roles/:id/barang-status` | Bearer + `ROLE_KELOLA` | `{ statusView: { KODE: boolean } }` → 400 status asing / nilai non-boolean / role admin dikunci |
| GET `/api/auth/me` | Bearer | `user` + `permissions[]` + `statusView[]` (null untuk admin) |

Gate permission di `GET /api/barang*` (seluruh router memakai `authenticate` + `authorize`):

| Permission | Endpoint |
|------------|----------|
| `BARANG_LIHAT` | `GET /`, `/hari-ini`, `/search`, `/export`, `/:id`, `/:id/riwayat` |
| `BARANG_STATISTIK_LIHAT` | `GET /status-summary`, `/summary`, `/stats`, `/batch-rentang-tanggal`, `/finishgood-per-bulan` |
| `BARANG_SCAN` | `GET /scan/:kodeBarang`, `POST /scan/bulk` (bulk juga butuh `BARANG_UBAH_STATUS`) |
| `BARANG_UBAH_STATUS` | `PATCH /:id/status`, `POST /bulk-status`, `POST /scan/bulk` |
| `BARANG_GENERATE` | `GET /generate-info`, `POST /generate` |
| `BARANG_KELOLA` | `POST /`, `PUT /:id`, `DELETE /:id` |
| `MUTASI_GUDANG` | `POST /api/mutasi-gudang` (seed ke `user`, `gudang`) |
| `ROLE_KELOLA` | `/api/roles*` |

Filter status per role: `GET /api/barang*` hanya mengembalikan status dalam `statusView` role; `?status=` di luar scope → `403`; tanpa token → `401`; tanpa permission → `403`. Matriks awal role `gudang`: `FINISHGOOD`+`RETUR` terlihat, `REGISTER`/`OUT`/`BAD` tidak. Key cache Redis mencakup scope (`barangScopeKey`) supaya hasil role A tidak tersaji ke role B. Endpoint `barang-group` memfilter barang + `_count` dengan scope yang sama.

```bash
docker exec backend-api-1 npx prisma migrate deploy   # terapkan migration RBAC
docker exec -i backend-api-1 npx prisma db seed       # idempotent, aman dijalankan ulang
```

---

## 5. Product
Router `src/routes/products.ts`, controller `src/controller/product/product.ts`, model `src/model/product/product.ts`.

| Endpoint | Deskripsi | Success |
|----------|-----------|---------|
| GET `/api/products` | List + `variants { product, style, color, size }`, cache Redis 60 dtk, tanpa pagination | 200 array |
| GET `/api/products/:id` | Detail | 200 / `404 { message: "Produk tidak ditemukan" }` |
| POST `/api/products` | Body `{ nama, prefix }` wajib → `400`; broadcast `product.created` | 201 product |
| PUT `/api/products/:id` | Body `{ nama }` wajib → `400`; broadcast `product.updated` | 200 |
| DELETE `/api/products/:id` | Cascade hapus variant (`onDelete: Cascade`, `prisma/schema.prisma:75`); broadcast `product.deleted { id }` | 200 |
| GET `/api/products/:id/variants` | Variant milik product | 200 |
| POST `/api/products/:id/variants` | `{ styleId, colorId, sizeId, tanggal? }` wajib kecuali tanggal → `400`; duplicate unique `[productId,styleId,colorId,sizeId]` → `409`; broadcast `variant.created` | 201 |
| PATCH `/api/products/:id/variants/:variantId` | `{ tanggal? }` optional; broadcast `variant.updated` | 200 |
| DELETE `/api/products/:id/variants/:variantId` | Restrict jika dipakai Barang/Counter → `500`; broadcast `variant.deleted` | 200 |

`kodeVariant` auto-generated `<PREFIX_UPPERCASE><3 digit>` dari id variant terakhir +1.

---

## 6. Variant Produk Standalone
Router `src/routes/variant-produk.ts`, controller `src/controller/variantproduk/variantproduk.ts`, model `src/model/variantproduk/variantproduk.ts`.
Response row adalah raw-SQL row (`VariantProdukRow`: `id, kodeVariant, productId, namaProduk, styleId, namaStyle, colorId, namaColor, sizeId, namaSize, urutanSize, tanggal`), **bukan** Prisma view — schema.prisma tidak mendefinisikan view.

| Endpoint | Validasi | Success/Error |
|----------|----------|---------------|
| GET `/api/variant-produk?productId=&styleId=&colorId=&sizeId=` | tiap query jika ada harus integer >0 → `400` | 200 array |
| GET `/api/variant-produk/:id` | NaN → `400 { message: "Parameter 'id' tidak valid" }` | 200 / `404 { message: "Variant produk tidak ditemukan" }` |
| POST `/api/variant-produk` | `{ productId, styleId, colorId, sizeId, tanggal? }`; ID integer >0 → `400`; `tanggal` valid → `400`; FK hilang → `404`; duplicate → `409`; broadcast `variant.created` | 201 |
| PUT `/api/variant-produk/:id` | parsial, min 1 field → `400`; `P2002` → `409`; `P2003` → `400 { message: "styleId, colorId, atau sizeId merujuk data yang tidak ada" }`; broadcast `variant.updated` | 200 / 404 |
| DELETE `/api/variant-produk/:id` | `P2003` restrict → `409 { message: "Variant tidak dapat dihapus karena masih direferensikan..." }`; broadcast `variant.deleted` | `200 { message: "Variant berhasil dihapus" }` |

---

## 7. Style / Color / Size (Master Referensi)
Router `src/routes/styles.ts|colors.ts|sizes.ts`, controller `src/controller/style|color|size/*.ts`. Semua tanpa auth. Schema `Style/Color/Size` (`prisma/schema.prisma:33-59`): `nama @unique`, `Size.urutan Int default 0`.

| Endpoint | Body/Validasi | Success/Error |
|----------|---------------|---------------|
| GET `/api/styles`, `/api/colors`, `/api/sizes` | — | 200 array |
| GET `/:id` | integer >0 → 400 | 200 / 404 |
| POST `/` | styles/colors `{ nama }` wajib trim → 400; sizes `{ nama, urutan? }`, `urutan` integer >=0 → 400 | 201 / `409 Nama ... sudah ada` (P2002) |
| PUT `/:id` | styles/colors `{ nama }` wajib; sizes min satu `nama`/`urutan` → 400 | 200 / 404 (P2025) / 409 |
| DELETE `/:id` | — | 200 `{ message }` / 404 / `409 ... masih dipakai variant` (P2003) |

Seed awal via `prisma/seed.ts`.

---

## 8. Barang
Router `src/routes/barang.ts` — **urutan penting**: `/generate-info`, `/generate`, `/`, `/status-summary`, `/stats`, `/batch-rentang-tanggal`, `/finishgood-per-bulan`, `/search`, `/export`, `/scan/:kodeBarang`, `/scan/bulk`, `/bulk-status`, `/:id/*`, `/:id` terakhir.
Controller `src/controller/barang/*.controller.ts`, model `src/model/barang/barang*.ts`.

### 8.1 Generate & Generate-Info

**GET /api/barang/generate-info?variantId=1** (`generate.controller.ts:9`)
- `variantId` wajib angka → `400`; variant hilang → `404`.
- 200:
```json
{ "variantId": 1, "kodeVariant": "W001", "tanggal": "2026-09-03",
  "batch": { "kodeBatch": "BC001", "totalProduksi": 123, "kapasitas": 5000, "remaining": 4877 },
  "nextNumber": 45 }
```
`nextNumber` dari `BarangCounter (batchId, variantId, tanggal)` +1; belum ada batch → dummy `BC001`. Catatan: `ProductionBatch.nomorBatch` bertipe **Int** di DB; string `BC001` hanya format display/barcode.

**POST /api/barang/generate** (`generate.controller.ts:27`)
```json
{ "variantId": 1, "jumlah": 100 }
```
- `variantId` angka wajib → `400`; `jumlah` 1..50000 → `400` (`minimal 1` / `maksimal 50000`); variant hilang → `404`.
- Barcode: `BC{batch 3 digit}-{kodeVariant}-{DDMMYY}-{urut 4 digit}`, cth `BC001-W001-250826-0001`. Counter per `(batchId, variantId, tanggal)`.
- Batch kapasitas `5000` (`BATCH_KAPASITAS`); penuh → `SELESAI` + batch baru; 1 request bisa split multi-batch. Transaction + `SELECT FOR UPDATE`, timeout 120s, retry 5x (`P2002`/`P2034`/deadlock).
- Side-effect: `Barang` status `REGISTER`, `RiwayatBarang "Barang dibuat"`, update `totalProduksi`. Broadcast `barang.generated`.
- 201: `{ message, totalDibuat, batches: [{ kodeBatch, batchId, jumlah, barang: [{id, kodeBarang}] }] }`.

### 8.2 CRUD Single Barang

**POST /api/barang** (`crud.controller.ts:16`)
- Body `{ variantId*, batchId?, kodeBarang?, tanggal?, status?, keterangan? }`: `variantId` angka wajib; `batchId` angka jika ada; `status` salah satu enum; `tanggal` valid Date; `kodeBarang` kosong → auto-generate; `batchId` kosong → batch AKTIF/baru.
- 201 + broadcast `barang.created`. 404 variant/batch hilang, 409 duplicate `P2002`.

**PUT /api/barang/:id** (`crud.controller.ts:85`)
- Min 1 field → `400`; validasi sama; `tanggal: null` boleh (skip). 200 + broadcast `barang.updated`. 404/409.

**DELETE /api/barang/:id** (`crud.controller.ts:172`)
- Hapus `RiwayatBarang` dulu (Restrict), baru `Barang`, decrement `batch.totalProduksi`. 200 `{ message: "Barang berhasil dihapus", id }` + broadcast `barang.deleted`. 404 jika hilang.

### 8.3 List / Filter / Pagination

**GET /api/barang** (`query.controller.ts:38`)
- Query: `page` default 1 min 1; `limit` default 20 max 100; `variantId`/`batchId` angka → 400 jika NaN; `status` enum → 400; `tanggal` (`YYYY-MM-DD`) shortcut 1 hari penuh, **diabaikan jika `tanggalAwal`/`tanggalAkhir` dikirim**; `tanggalAwal > tanggalAkhir` → 400.
- Per-hari: `?tanggal=2026-08-26`. Per-minggu: `?tanggalAwal=..&tanggalAkhir=..`. Per-bulan: range 1 bulan penuh.
- 200: `{ data: [...include variant(product,style,color,size)+batch], meta: { page, limit, total, totalPages } }`.

**GET /api/barang/hari-ini** (`query.controller.ts:getBarangHariIniHandler`)
- Shortcut untuk `GET /api/barang?tanggal=<hari ini>` — filter `tanggalAwal`/`tanggalAkhir` dipaksa ke hari ini (start/end-of-day UTC, sama seperti `?tanggal=`), query tanggal lain diabaikan.
- Query opsional: `page` (default 1), `limit` (default 20, max 100), `variantId`, `batchId`, `status` (validasi sama seperti list → 400).
- 200: `{ tanggal: "YYYY-MM-DD", data: [...], meta: { page, limit, total, totalPages } }`.

**GET /api/barang/status-summary** + alias **GET /api/barang/summary** (`query.controller.ts:164`, `barang.stats.ts:39`)
- 200 bentuk aktual: `{ total: 20, perStatus: { REGISTER: 10, FINISHGOOD: 5, RETUR: 2, OUT: 3, BAD: 0 } }`.

**GET /api/barang/stats?variantId=&batchId=** (`query.controller.ts:173`, `barang.stats.ts:74`)
- 200: `{ total, perStatus, perVariant: [{variantId, nama, total}], perBatch: [{batchId, nomorBatch, total}] }`. Catatan: `perBatch` difilter `status != REGISTER`.

**GET /api/barang/batch-rentang-tanggal?tanggalAwal=&tanggalAkhir=**, **GET /api/barang/finishgood-per-bulan?variantId=&productId=&tanggalAwal=&tanggalAkhir=**
- Normalisasi tanggal sama (start/end-of-day UTC), range invalid → 400. Finishgood group `YYYY-MM` (`FinishgoodPerBulanRow { bulan, tahun, bulanAngka, variantId, productId, jumlah }`).

### 8.4 Detail / Riwayat

**GET /api/barang/:id** — 400 id invalid, 404 hilang, 200 include variant+batch.

**GET /api/barang/:id/riwayat** (`query.controller.ts:144`, `barang.ts:215`)
- 400/404 standar. 200 bentuk aktual:
```json
{ "data": [ { "id":1, "barangId":1, "status":"REGISTER", "tanggal":"...", "keterangan":"Barang dibuat" } ],
  "summary": { "kodeBarang":"BC001-...", "currentStatus":"REGISTER", "total": 2 } }
```
descending by tanggal.

### 8.5 Scan Single & Bulk

**GET /api/barang/scan/:kodeBarang** (`scan.controller.ts:6`)
- `kodeBarang` wajib → 400. 200 include variant+batch. 404 `Barang tidak ditemukan`.

**POST /api/barang/scan/bulk** (`scan.controller.ts:24`, `barang.ts:271`) — tanpa auth.
```json
{ "kodeBarang": ["BC001-W001-030926-0001", "BC001-W001-030926-0002"],
  "status": "FINISHGOOD", "keterangan": "QC pass - optional" }
```
- Validasi: `kodeBarang` array min 1 → 400; `status` enum → 400.
- Model: dedup (`duplicates` → `failed "Duplicate barcode dalam request"`), loop sequential, per-item `findUnique` → `failed "Barang tidak ditemukan"`, cek `VALID_TRANSITIONS[current].includes(newStatus)` — **same-status DITOLAK** (beda dengan `/bulk-status`), per-item `prisma.$transaction` (update + `riwayatBarang.create`), bukan global transaction (partial success mungkin).
- Broadcast per success `barang.status_updated`.
- Selalu 200 (kecuali validasi 400):
```json
{ "success": [...include variant+batch],
  "failed": [{ "kodeBarang":"...", "error":"Barang tidak ditemukan | Duplicate barcode dalam request | Transisi status dari OUT ke FINISHGOOD tidak valid" }],
  "summary": { "total": 4, "success": 1, "failed": 3 } }
```
`total` = panjang array asli termasuk duplikat.

### 8.6 Status Update Single & Bulk (by id)

**PATCH /api/barang/:id/status** (`status.controller.ts:10`, `barang.status.ts:30`)
- `{ status*, keterangan? }`; `validateTransition` **allow same-status** (`current===next → true`), tetap tulis riwayat. 200 + broadcast. 404 hilang, 400 transisi invalid.

**POST /api/barang/bulk-status** (`status.controller.ts:41`, `barang.status.ts:87`)
```json
{ "items": [{ "id":1, "status":"FINISHGOOD", "keterangan":"ok" }] }
```
- `items` array min 1 → 400; max 500 → 400; tiap `id` number → 400; tiap `status` enum → 400. Loop `updateBarangStatus` sequential (allow same-status). 200 `{ success, failed: [{id, error}], summary }` + broadcast per success.

### 8.7 Search & Export

**GET /api/barang/search?q=&limit=** — `q` wajib trim, max 100 char → 400; `limit` default 20 max 50. 200 `{ data, meta: { q, count } }`.

**GET /api/barang/export?format=csv|json&...filter** (`export.controller.ts:15`)
- `format` default `json`, selain itu → 400; `limit` max 10000 default 10000; filter sama seperti list.
- JSON: `Content-Disposition: attachment; filename="barang-export-<ts>.json"`, body `{ data, meta }`. CSV: `text/csv`, header `id,kodeBarang,status,tanggal,variantId,kodeVariant,product,style,color,size,batchId,nomorBatch`, escape koma/quote.

### 8.8 Production Order (Master Produksi)

Router `src/routes/production-orders.ts` (tanpa auth), controller `src/controller/production-order/production-order.ts`, model `src/model/production-order/production-order.ts`. Tanpa cache Redis, tanpa broadcast WS (verified: tidak ada import `broadcast`/`redis` di kedua file).

**GET /api/production-orders** — list header + `_count.items`, `orderBy createdAt desc`. Tanpa pagination/filter. 200 array.

**GET /api/production-orders/:id[?summary=1]** — detail + `items[]` (include `variant { product, style, color, size }`, order `priority asc, variantId asc`). `?summary=1` tambah `ringkasan[]` grup per `"Style Color"`: `{ item, total, priority, persentase }`, `persentase = total/order.totalQty*100` 2 desimal (0 bila `totalQty` 0), `priority` dari item pertama grup. ID harus integer >0 → `400 { message: "ID harus angka bulat positif" }`; hilang → 404.

**POST /api/production-orders**
```json
{ "nomor": "PO-202610-001", "periode": "2026-10", "label": "…", "status": "AKTIF",
  "items": [{ "variantId": 1, "qty": 600, "priority": 5 }] }
```
- `nomor`/`periode` string non-kosong wajib → 400; `status` salah satu `DRAFT/AKTIF/SELESAI/BATAL` → 400; `items` bila ada harus array, tiap item `variantId` integer >0, `qty` integer >=0, `priority` integer >=0 bila ada → 400.
- `nomor`/`periode` di-trim, `label` kosong → `null`, `status` default `AKTIF`, `totalQty = sum(qty)`.
- 201 + detail (include items). `P2002` nomor duplikat → `409 { message: "Nomor production order sudah ada" }`. Catatan: `variantId` FK invalid saat create nested → 500 (tidak dipetakan ke 404, beda dengan `POST /:id/items`).

**PUT /api/production-orders/:id** — update parsial header (`nomor/periode/label/status`) saja; **tidak menyentuh items/`totalQty`**. Validasi sama. `P2002` → 409, `P2025` → 404.

**DELETE /api/production-orders/:id** — hapus order, items ikut cascade (`onDelete: Cascade`, `schema.prisma:220`). `P2025` → 404, else 200 `{ message: "Production order berhasil dihapus" }`.

**POST /api/production-orders/:id/items** — `{ variantId*, qty >=0, priority? default 0 }`, validasi sama → 400. Sukses 201 + `syncTotal` (hitung ulang `totalQty` dari seluruh item). `P2002` → `409 "Variant sudah ada di order ini"`; `P2003`/`P2025` → `404 "Production order atau variant tidak ditemukan"`.

**PUT /api/production-orders/:id/items/:itemId** — parsial `{ qty?, priority? }`, min satu field → 400; angka integer >=0 → 400. Sukses 200 + `syncTotal`. `P2025` → 404. Dipakai cell-edit frontend.

**DELETE /api/production-orders/:id/items/:itemId** — hapus by `itemId` + `syncTotal`. Tidak verifikasi item milik order (`delete where: { id: itemId }`, `production-order.ts:115`). `P2025` → 404, else 200 `{ message: "Item berhasil dihapus" }`.

**GET /api/production-orders/:id/capacities** — list `ProductionCapacity` milik order, order `urutan asc, id asc`. ID invalid → 400. Order hilang → 200 array kosong (tanpa 404).

**PUT /api/production-orders/:id/capacities** — body **array** (boleh `[]` untuk kosongkan), tiap item `{ stage*, kapasitasWeekday?, kapasitasSabtu?, mulai?, selesai?, hariKerja?, totalKapasitas?, catatan?, urutan? }`: `stage` non-kosong, angka integer >=0, tanggal valid, `catatan` string bila ada → 400. Replace-all dalam satu transaction (`deleteMany` + `createMany`), response 200 list baru. Order hilang → 404. `hariKerja`/`totalKapasitas` disimpan mentah sesuai input (input manual dari sheet, bukan kalkulasi).

**GET /api/production-orders/:id/schedule[?prep=YYYY-MM-DD,..&qc=..&sampai=YYYY-MM-DD]** — jadwal otomatis, fungsi murni `buildSchedule` (`src/model/production-order/schedule.ts`, tanpa tabel baru). Aturan: Senin–Jumat Jam 7, Sabtu Jam 3.5 (`kapasitasSabtu`), Minggu `LIBUR` target 0; target total tiap tahap = demand master (decal solid = sum item style Solid, decal motif = sum style Motif, sisanya = total order — seed menghitungnya, bukan hardcode); tanggal akhir bebas sampai kumulatif = target (guard 730 hari + stall 30 hari); target harian = cap mentah dicap sisa demand; target hanya di baris pertama tiap tanggal (baris lanjutan 0, ikut sheet); alokasi `Jumlah` ikut tahap TOP COAT (TOP COAT & PERAKITAN tidak diakru di hari fixed agar budget tak hangus); item urut priority, size urut `Size.urutan`; hari di `prep`/`qc` tanpa alokasi. Default `prep` = tgl 1–3 bulan `periode`, `qc` = 3 hari kerja terakhir bulan itu. Default tanpa `sampai`: jalan sampai selesai (bisa lewat bulan, tanpa ekor); bila `sampai` diisi: baris dipotong di tanggal itu + ekor `Penyesuaian` dan hari terakhir `QC & Packing`, sisa masuk `meta.sisa`. Response `{ order {id,nomor,periode,totalQty}, rows[] {tanggal,hari,size,jam,buffing,baseCoat,decalSolid,decalMotif,topCoat,perakitan,qc,item,jumlah}, rincian[] {tanggal,stage,variantId,size,item,jumlah} (item per tahap buffing/baseCoat/decalSolid/decalMotif/topCoat/perakitan/qc untuk SPK divisi), meta {dialokasikan,sisa,hariProduksi,prepDays,qcDays,akhirBulan} }`. ID invalid → 400, order hilang → 404.

Seed `prisma/seed-production-order.ts` (sumber `prisma/data/master-produksi-oktober-2026.ts`: `PO-202610-001`, periode `2026-10`, status `AKTIF`, produk `Windbreaker`, 5000 pcs, 24 baris = 6 style+color × 4 size):
- Upsert header by `nomor`, item by `(orderId, variantId)`; variant dibuat bila belum ada (`PREFIX + nomor milik produk`). Master product/style/color/size hilang → throw, seed gagal.
- Rerun menimpa header/qty/priority sumber, tapi tidak hapus item tambahan di DB; `totalQty` = sum sumber seed. Bukan satu transaksi global — gagal di tengah bisa parsial. Tidak buat Barang/ProductionBatch, tidak broadcast WS, tidak invalidate cache.

---

## 9. WebSocket Realtime
`src/websocket/socket.ts`, init di `api/index.ts` (non-Vercel). Channel Redis `product-events`, dua client ioredis pub/sub. Tanpa auth.

- Connect `ws://host:8000` → server kirim `{ message: "WebSocket terhubung" }` (`socket.ts:172`), simpan di `Set<WebSocket>`.
- Flow: controller `void broadcast(event)` → `redisPub.publish` → `redisSub.on("message")` → broadcast ke WS lokal.
- 11 event aktual (`AppEvent`, `socket.ts:81`):

| type | data | Pemicu |
|------|------|--------|
| `product.created` / `product.updated` | `Product` | POST / PUT `/api/products` |
| `product.deleted` | `{ id }` | DELETE product |
| `variant.created` / `variant.updated` | `ProductVariant` | POST / PATCH variant, POST / PUT `/api/variant-produk` |
| `variant.deleted` | `{ id }` | DELETE variant |
| `barang.generated` | `GenerateBarangResult { totalDibuat, batches }` | POST `/api/barang/generate` |
| `barang.status_updated` | `Barang` + variant + batch | PATCH status, POST `/bulk-status`, POST `/scan/bulk` (per success) |
| `barang.created` / `barang.updated` | `Barang` | POST / PUT `/api/barang` |
| `barang.deleted` | `{ id }` | DELETE barang |

Write production-order tidak emit event WS (verified: controller tanpa `broadcast`).

---

## 10. Domain Model & Aturan Bisnis
`prisma/schema.prisma` — provider `mysql`, output `generated/prisma` (jangan edit manual).

- **User** `id, name, email @unique, password (bcrypt), role default "user", timestamps`.
- **Product** `id, nama, prefix, variants[]` — prefix untuk `kodeVariant`.
- **Style/Color/Size** `id, nama @unique`; `Size.urutan Int default 0`.
- **ProductVariant** `id, kodeVariant @unique, productId, styleId, colorId, sizeId, tanggal?`; `@@unique([productId,styleId,colorId,sizeId])`; `Cascade` dari Product, `Restrict` dari Style/Color/Size.
- **ProductionBatch** `id, nomorBatch Int @unique, totalProduksi default 0, kapasitas default 5000, status AKTIF|SELESAI`.
- **Barang** `id, kodeBarang @unique, variantId, batchId?, tanggal?, status REGISTER default`; `Restrict` ke variant & batch.
- **RiwayatBarang** `id, barangId, status, tanggal default now(), keterangan?`; `Restrict`.
- **BarangCounter** `@@unique([batchId,variantId,tanggal])` — reset per kombinasi.
- **ProductionOrder** `id, nomor @unique, periode, label?, totalQty default 0, status DRAFT|AKTIF(default)|SELESAI|BATAL`, `@@index([periode],[status])`; **ProductionOrderItem** `id, orderId, variantId, qty default 0, priority default 0`, `@@unique([orderId,variantId])` (`schema.prisma:195-226`).
- **ProductionCapacity** `id, orderId, stage, kapasitasWeekday/Sabtu default 0, mulai?/selesai?, hariKerja/totalKapasitas default 0, catatan?, urutan default 0`, `@@unique([orderId,stage])`, cascade dari Order. Seed Oktober: mulai/selesai/hariKerja/catatan ikut sheet; `totalKapasitas` dihitung dari master (decal solid 2399 = sum Solid, decal motif 2601 = sum Motif, sisanya 5000 = total order). Jadwal live: kumulatif pas demand, 5000/0, 1 Okt–12 Nov.
- **Barcode:** `BC{batch 3 digit}-{kodeVariant}-{DDMMYY}-{4 digit}`, cth `BC001-W001-250826-0001`.
- Cascade: Product→Variant dan ProductionOrder→Item; Variant→OrderItem `Restrict`. Hapus variant yang dipakai Barang → 409 P2003.
- `totalQty`: di-set saat create dari sum items; dihitung ulang (`syncTotal`) hanya saat add/delete item; `PUT` header dan seed-rerun tidak merekonsiliasi item di luar sumbernya (lihat 8.8).

---

## 11. Error & Status Code

| Code | Kapan |
|------|-------|
| 200 | GET/DELETE/PATCH success; scan/bulk & bulk-status selalu 200 walau partial failed |
| 201 | POST create / generate success |
| 400 | Validasi (`wajib`, `tidak valid`, `Jumlah`, `harus` — `helpers.ts:10 errorStatus`) |
| 401 | Login salah; token hilang/invalid/revoked |
| 403 | `adminOnly` gagal |
| 404 | Pesan mengandung `tidak ditemukan` |
| 409 | Duplicate `P2002` (`sudah ada`) atau restrict `P2003` |
| 500 | Unexpected; beberapa handler sertakan `error` di body |

`errorMessage(error, fallback)` → `error.message` atau fallback. `errorStatus(msg)` → 404 / 400 / 500 sesuai substring di atas.

---

## 12. Resep Integrasi (untuk project lain)

### 12.1 Frontend baru (checklist minimal)
1. `GET /` cek koneksi. 2. `GET /api/products` isi dropdown produk. 3. `GET /api/variant-produk?productId=` isi variant. 4. `GET /api/barang/generate-info?variantId=` tampilkan `nextNumber`/sisa batch sebelum generate. 5. `POST /api/barang/generate` untuk produksi. 6. `POST /api/barang/scan/bulk` untuk QC/gudang (ingat: kirim array, handle `success`/`failed` per item, same-status = failed). 7. Subscribe WS `ws://host:8000` untuk refresh list saat `barang.status_updated` / `barang.generated`. 8. `GET /api/barang/export?format=csv` untuk laporan.

### 12.2 Contoh TypeScript shared types (copy ke project lain)
```ts
export type StatusBarang = "REGISTER" | "FINISHGOOD" | "RETUR" | "OUT" | "BAD";
export interface BulkScanRequest { kodeBarang: string[]; status: StatusBarang; keterangan?: string; }
export interface BulkScanResponse<T = unknown> {
  success: T[]; failed: { kodeBarang: string; error: string }[];
  summary: { total: number; success: number; failed: number };
}
export interface Paged<T> { data: T[]; meta: { page: number; limit: number; total: number; totalPages: number }; }
```

### 12.3 Untuk agent AI yang mau ubah backend ini
- Pola wajib: route → controller (validasi+status) → model (`src/lib/prisma.ts` shared instance). Jangan query DB di route.
- ESM: import lokal pakai `.js`. Strict TS, hindari `any`.
- Schema berubah → migration baru + generate; jangan edit `generated/` atau migration lama.
- Perilaku endpoint berubah → update/tambah test di `tests/` (`auth`, `variantproduk`, `barang`, `production-order` — mock model+WS).
- Jangan commit/reset/clean tanpa instruksi. Jangan reset DB destruktif.

---

## 13. Contoh cURL

```bash
BASE=http://localhost:8000

# login
curl -X POST $BASE/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"admin@rsv.com","password":"admin123"}'

# buat product + variant
curl -X POST $BASE/api/products -H "Content-Type: application/json" \
  -d '{"nama":"Helmet X","prefix":"W"}'
curl -X POST $BASE/api/products/1/variants -H "Content-Type: application/json" \
  -d '{"styleId":1,"colorId":1,"sizeId":1}'

# master referensi
curl $BASE/api/styles && curl $BASE/api/colors && curl $BASE/api/sizes

# generate
curl -X POST $BASE/api/barang/generate -H "Content-Type: application/json" \
  -d '{"variantId":1,"jumlah":10}'
curl "$BASE/api/barang/generate-info?variantId=1"
curl "$BASE/api/barang?page=1&limit=20&status=REGISTER"
curl "$BASE/api/barang/hari-ini?status=REGISTER"
curl "$BASE/api/barang/scan/BC001-W001-030926-0001"

# bulk scan (same-status REGISTER->REGISTER = failed!)
curl -X POST $BASE/api/barang/scan/bulk -H "Content-Type: application/json" \
  -d '{"kodeBarang":["BC001-W001-030926-0001","BC001-W001-030926-0002"],"status":"FINISHGOOD","keterangan":"QC lulus"}'

# status by id (same-status OK)
curl -X PATCH $BASE/api/barang/1/status -H "Content-Type: application/json" \
  -d '{"status":"OUT","keterangan":"kirim distributor"}'
curl -X POST $BASE/api/barang/bulk-status -H "Content-Type: application/json" \
  -d '{"items":[{"id":1,"status":"RETUR"},{"id":2,"status":"BAD","keterangan":"cacat"}]}'

curl "$BASE/api/barang/1/riwayat"
curl "$BASE/api/barang/status-summary"
curl "$BASE/api/barang/stats?variantId=1"
curl "$BASE/api/barang/search?q=BC001&limit=10"
curl "$BASE/api/barang/export?format=csv&status=FINISHGOOD" -o export.csv

# production order
curl $BASE/api/production-orders
curl "$BASE/api/production-orders/1?summary=1"
curl -X POST $BASE/api/production-orders -H "Content-Type: application/json" \
  -d '{"nomor":"PO-202610-002","periode":"2026-10","items":[{"variantId":1,"qty":100}]}'
curl -X POST $BASE/api/production-orders/1/items -H "Content-Type: application/json" \
  -d '{"variantId":2,"qty":50,"priority":1}'

# websocket: wscat -c ws://localhost:8000
# -> {"message":"WebSocket terhubung"}

# logout
curl -X POST $BASE/api/auth/logout -H "Authorization: Bearer <token>"
```

---

## 14. File Referensi
- Routes: `src/routes/auth.ts`, `admin.ts`, `products.ts`, `variant-produk.ts`, `barang.ts`, `production-orders.ts` (+ `/:id/capacities`, `/:id/schedule`), `styles.ts`, `colors.ts`, `sizes.ts`, `src/app.ts`
- Controller: `src/controller/auth/auth.ts`, `product/product.ts`, `variantproduk/variantproduk.ts`, `production-order/production-order.ts`, `style|color|size/*.ts`, `src/controller/barang/*`
- Model: `src/model/product/product.ts`, `variantproduk/variantproduk.ts`, `production-order/production-order.ts`, `src/model/barang/barang.ts|barang.generate.ts|barang.status.ts|barang.stats.ts|barang.crud.ts`, `style|color|size/*.ts`, `user/user.ts`
- Lib: `src/lib/prisma.ts`, `jwt.ts`, `tokenBlacklist.ts`, `redis.ts`, `barangCache.ts`
- WS: `src/websocket/socket.ts` — runtime `api/index.ts`
- Schema/env/runtime: `prisma/schema.prisma`, `prisma/seed.ts`, `prisma/seed-production-order.ts`, `prisma/data/master-produksi-oktober-2026.ts`, `.env.example`, `package.json`, `docker-compose.yml`, `vercel.json`
- Test acuan: `tests/auth.test.ts`, `tests/variantproduk.test.ts`, `tests/barang.test.ts`, `tests/production-order.test.ts`

> Changelog doc ini: port default dikoreksi `3000`→`8000`; tabel quick-contract + auth matrix ditambah untuk konsumen luar; bentuk aktual `status-summary {total,perStatus}`, `stats {total,perStatus,perVariant,perBatch}`, `riwayat {data,summary:{kodeBarang,currentStatus,total}}` dikoreksi dari source; `nomorBatch` Int (string hanya display) ditegaskan; 11 WS event (termasuk `barang.created/updated/deleted`) diverifikasi dari `socket.ts`; penegasan tidak ada MQTT/RFID/IoT; perbedaan same-status scan/bulk vs bulk-status didokumentasikan; `GET /api/barang/hari-ini` ditambahkan; transisi `OUT→RETUR` / `BAD→FINISHGOOD` dikoreksi dari source (bukan terminal); section 8.8 + quick-contract + model + cURL + file referensi untuk `production-orders` ditambahkan.
