import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["tests/**/*.test.ts"],
    setupFiles: ["dotenv/config"],
    env: { TZ: "Asia/Jakarta" },
  },
});
